
# OBD Python - Test program 
# Julio Ribeiro  26/11/2014

from bluetooth import *
import os
import sys
import time
import variables
import bluetooth

### ----------------------------------- CLASS OF OBD COMMUNICATION ------------------------------------
class OBDCom():

	retryLimit = 0
		
	def __init__(self):
		
		# Bluetooth OBD Server adapter parameters
		host = '00:0D:18:00:00:01'
		#host = '18:1E:B0:0D:C0:6B' 
		port = 1
		self.wait = 0.2
		
		try:
			self.bt = BluetoothSocket(RFCOMM)
			self.bt.connect((host,port))
			print('Bluetooth connected')
			OBDCom.retryLimit =0
		
		except:
			print('Failed to connecto to bluetooth')
			self.__retryConnect()
			
	def __retryConnect(self):
		if OBDCom.retryLimit <= 3:
			print('Retrying',OBDCom.retryLimit)
			OBDCom.retryLimit +=1
			self.__init__()
		print('Bluetooth connection not possible')
		OBDCom.retryLimit =0
		quit()
		
			
### FUNCTION: Generic send command to OBD		
	def sendCmd(self, cmd, timeout):
		try:
			self.bt.send(cmd)
			time.sleep(timeout)
			data = self.bt.recv(512)
			data = str(data)[2:].replace('\\r',' ').split()
			return data
		except:
			print('Error issuing command',cmd)
			return False



### FUNCTION: Start session
	def startSession(self):
		print('Initialization sequence...')
		try:
			results = []
			for at in ['AT I\r','AT E1\r', 'AT H0\r','AT S1\r', 'AT TP0\r','AT DPN\r','0100\r']:   # initialization AT Commands: MUST HAVE 7 valids AT or PIDs
				data = self.sendCmd(at,0.5)    
				results.append(data[2])									# add at command responses to the vector 'results'
				print(at[:5],':',data[2])
			data = self.sendCmd('0902\r',2)								# get the vehicle identification chassi number (VIN). Ex: 0902 014 0: 49 02 01 ....
			bytes = int(data[1],16)										# total of bytes in the response of command 0902 (ex: 014  (20 DEC) )
			first = data.index('0:')									# fix position index of start reading of 1st line
			vin = ''
			for i in range(bytes-1):									# scan from byte 0 up to 19
				try:
					vin += chr( int(data[first+4+i],16) )				# the first 3 bytes after '0:' is a metadata (to discard or for check purposes)
				except:
					i+=1												# every time a non-hexa symbols apear (ex: '1:'), ignore it and increment counter
					pass
			print(vin)
			results.append(vin)											# add VIN to the vector 'results'
			results.append(self.getListPids())							# add Supported PIDs to the vector 'results'
			
			if '31'in results[8]:
				data=(self.sendCmd('0131\r',1))							# if 'Distance traveled' PID is supported, then include initial km in the vector
				km=int(data[3],16)*256 + int(data[4],16)
				results.append(km)
			
			return results												# this vector has at position: 1 to 4 ==> 'OK' and 7 ==> VIN and 8 ==> support. PIDS
		except:
			print('Session Initialization Error')
			return False



### FUNCTION: Get all supported PIDs	
	def getListPids(self, map=False, mask=['04','0C','0D']):
		pids = []
		OBD_PID_LIST = ['0100\r', '0120\r', '0140\r', '0160\r','0180\r']
		for cmd in OBD_PID_LIST:
			binario =''	
			try:
				self.bt.send(cmd)
				time.sleep(self.wait)
				data = self.bt.recv(128).split()[3:7]
				for i in range(len(data)):
					binario +=bin(int(data[i],16))[2:].zfill(8)	 
				for b in range(len(binario)):
					if int(binario[b]) == 1:
						pid = hex( int(b+1)+ int(cmd[2:4],16) )[2:].zfill(2).upper()
						pids.append(pid)												# fill a list of supported PIDs
			except:
				print('An error has occurred gathering list of supported PIDs')
		
		print('There are a total of',len(pids),'supported PIDs:')
		for i in pids:
			print('PID:',i,'\t',variables.dicpid['01'][3][i])
		if map == True:
			mapedPids = self.mapPids(pids,mask)
			print(' *** Mapped PIDs enabled ***')
			for i in mapedPids:
				print('PID:',i,'\t',variables.dicpid['01'][3][i])
			return mapedPids
		return pids



### FUNCTION: Maps a obtained PID list to a desirable PID list using a pre-defined fileter (target)
	def mapPids(self,pids,target):
		resultPids = []
		for t in range(len(target)):
			for p in range(len(pids)):
				if target[t]==pids[p]:
				 	resultPids.append(pids[p])
		return resultPids


### FUNCTION: Extract, convert and return decimal PID value
	def getValue(self,mode,pid,bytes):
		dicpid = variables.dicpid
		try:
			if len(bytes)==1:
				A = int(bytes[0],16)
			elif len(bytes)==2:
				A = int(bytes[0],16)
				B = int(bytes[1],16)
			elif len(bytes)==3:
				A = int(bytes[0],16)
				B = int(bytes[1],16)
				C = int(bytes[2],16)
			elif len(bytes)==4:
				A = int(bytes[0],16)
				B = int(bytes[1],16)
				C = int(bytes[2],16)
				D = int(bytes[3],16)
			elif len(bytes)==5:
				A = int(bytes[0],16)
				B = int(bytes[1],16)
				C = int(bytes[2],16)
				D = int(bytes[3],16)
				E = int(bytes[4],16)
			else:
				label = 'Raw data'
				return label, bytes
		except:
			label = 'No data'
			return label,'Error'
		return dicpid[mode][3][pid],eval(dicpid[mode][2][pid])
	

### FUNCTION: Close bluetooth communication
	def close(self):
		print('Closing bluetooth socket...')
		try:
			self.bt.close()
			print('Bluetooth socket are closed!')
		except:
			print('Error closing bluetooth')






### ----------------- Raspberry Server Bluetooth for Android dashboard (TO be implemented!!)----------------------------
class BTServer():

	def __init__(self):
		port = 0
		self.server_sock=bluetooth.BluetoothSocket( bluetooth.RFCOMM )
		self.server_sock.bind(("",port))
		self.server_sock.listen(1)
		
	def acceptConnection(self):
		print('Waiting for client connection...')
		self.client_sock,address = self.server_sock.accept()
		print('Accepted connection from ',address)	
		
	def getData(self):
		data = self.client_sock.recv(1024)
		print('received [%s]' % data)
		return data
	def close(self):
		print('Closing bluetooth socket...')
		self.client_sock.close()
		self.server_sock.close()
		print('Bluetooth socket are closed!')
		