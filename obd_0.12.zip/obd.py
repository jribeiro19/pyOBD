
# OBD Python - Test program 
# Julio Ribeiro  26/11/2014

from bluetooth import *
import os
import sys
import time
import variables
import reporter
import obdlib

# Generic variables
WAIT = 0.2			# Wait time to read input bluetooth buffer after sending a command
LOW_BAT = 13.2		# Minimum car's battery voltage allowed to run the script


# OBD variables
dicpid = variables.dicpid
targetPids = ['04','0A','0B','0C','0D','10','11','1F','23','43','45','49','4A','4B','59','5A','5E','61','62','63']

# Log file
rep=reporter.Report()

# Initialization sequence
bt = obdlib.OBDCom()
session = bt.startSession()
if session == False:
	bt.close()
	quit()
else:
	rep.login(session)


# Get PID list to query
pids = bt.getListPids(True,targetPids)
try:
	rep.appendLogin('Target PIDs:'+str(pids)+'\n')
except:
	pass


# Setup headers of report OBD2Output.txt according to availables PIDs
lbl = []
for i in pids:
	lbl.append(dicpid['01'][3][i])
rep.addHeader(lbl)


# Loop through all car PIDs available in "OBD MODE:01"
error = 0			# error count variable
sucess = 0			# success count variable
sample = 0			# total samples counter
while 1:		
	sample +=1
	values = []
	try:
		for id in pids:
			cmd = '01'+id+'\r'
			data = bt.sendCmd(cmd,WAIT)
			mode = data[0][0:2]							# can be changed to '01' once mode is a constant
			pid = data[0][2:4] 							# can be change to 'id' once pid is a variable already known
			bytesToRead = dicpid[mode][1][pid]
			bytes = data[3:(3+bytesToRead)]
			label,result = bt.getValue(mode,pid,bytes)
			values.append('%.4f' % result)
			print(sample,time.time(),pid, '%.4f' % result)
			sucess+=1.0
		rep.write(values)
	except:
		print('Error decoding',error)
		error +=1
		if error > 2:
			WAIT = WAIT*1.1
			
		if error >= 6:
			break
		
		try:
			vbat = bt.sendCmd('ATRV\r',0.2)					# return a list like '['ATRV','12.8V','>']
			vbat = float(vbat[1][: (vbat[1].index('V'))])   # get voltage ([1]), but only numbers and dot, up to 'V' character
			if vbat < LOW_BAT:
				print('Power supply under ', LOW_BAT,'(V). Starting sleep mode...')
				bt.sendCmd('ATLP\r',0.1)
				break
		except:	
			pass
		pass
	print('-----')


bt.close()
rep.close()
quit()

