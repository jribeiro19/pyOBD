# OBD Python - Test program 
# Julio Ribeiro  26/11/2014

import os
import sys
import time
import variables

class Report():

	def __init__(self,output='OBD2Output.txt', error='OBDError.txt', session='OBDSession.txt', separator = ';'):
		self.o = output
		self.e = error
		self.s = session
		self.separator = separator
		self.dic = {}
		try:
			self.fho = open(self.o, 'a')
			self.fhe = open(self.e, 'a')
			self.fhs = open(self.s, 'a')
		except:
			print('Error: Is not possible to open output files. Check:',self.o,self.e, self.s)
				

	def addHeader(self, headers):
		hdr = 'Sample'+self.separator+'Datetime'+self.separator		
		for i in headers:
			hdr += i+self.separator
		try:
			self.fho.write(hdr+'\n')
		except:
			print('Error writing headers')
			out = str(time.ctime()) + self.separator + ' Error writing headers to the output file. Headers received: '+ str(headers)
			self.fhe.write(out +'\n')
		 
	
	def write(self,data='-'):
		self.data = data
		try:
			value = ''
			for i in range(len(self.data)):
				value += str(self.data[i])+self.separator
			out = str(time.time())+ self.separator + str(time.ctime()) + self.separator + value
			self.fho.write(out +'\n')
		except:
			print('Error writing data')
			out = str(time.ctime()) + self.separator + ' Error writing data to the output file. Data received: '+ str(self.data)
			self.fhe.write(out +'\n')
		 
		 
	def login(self,session):
		try:
			if type(session) == list:
				self.fhs.write('-'*80+str('\n'))
				self.fhs.write('Session Id : '+ str(hex(int(time.time())))+'\n')
				self.fhs.write('Login time : '+ str(time.ctime())+'\n')
				self.fhs.write('Vehicle Id : '+ str(session[7])+'\n')
				self.fhs.write('Protocol   : '+ str(variables.dicproto[session[5]])+'\n')
				self.fhs.write('Supported  : '+ str(len(session[8]))+' PIDs\n')
				for i in session[8]:
					self.fhs.write('\tPID: ' +str(i) +'\t' +str(variables.dicpid['01'][3][i])+'\n')
				if len(session)==10:
					self.fhs.write('Initial Km : '+str(session[9])+'\n')
		except:
			print('Failed to login')
			
			
	def appendLogin(self,content):
		try:
			self.fhs.write(content)
		except:
			print('Failed to append login')
					
	
	def close(self):
		print('Closing report files....')
		try:
			self.fho.close()
			self.fhe.close()
			self.fhs.write('Logoff time: '+ str(time.ctime())+str('\n'))
			self.fhs.close()
			print('Report files are closed!')
		except:
			print('Error closing report files')
			 